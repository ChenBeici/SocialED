"""
``SocialED`` is a python library for social event detection
"""


__version__ = '1.1.5'
